# Quiz Arena v2 — Uzbekcha + Русский

## Imkoniyatlar
- O'zbekcha va ruscha interfeys: `/lang`
- Yakka quiz: `/play ID`
- Jonli xona: admin `/room ID`, ishtirokchilar `/join KOD`, admin `/startgame KOD`
- Tez javob uchun ko'proq ball (jonli o'yinda)
- TOP-10 natijalar: `/leaderboard ID`
- Admin quiz yaratadi va savol qo'shadi

## O'rnatish (Windows)
1. Python 3.10 yoki yangiroq versiyani python.org saytidan o'rnating. O'rnatishda "Add Python to PATH" ni belgilang.
2. ZIP papkasini oching.
3. Papka ichida terminal oching (File Explorer manzil satriga `cmd` yozib Enter bosing).
4. Buyruqlar:
   `py -m venv .venv`
   `.venv\\Scripts\\activate`
   `py -m pip install -r requirements.txt`
5. `.env.example` faylidan nusxa olib `.env` deb nomlang.
6. @BotFather tokenini `BOT_TOKEN=` qatoriga yozing.
7. Telegram numeric ID'ingizni `ADMIN_IDS=` qatoriga yozing. ID olish uchun Telegramdagi @userinfobot yordam beradi.
8. `py -m bot.main`

## Admin
- `/create` — quiz yaratish
- `/add ID | Savol | A | B | C | D | to'g'ri javob (1-4) | soniya`
- `/publish ID` — e'lon qilish
- `/room ID` — jonli xona ochish
- `/startgame KOD` — xonani boshlash

Misol:
`/add 1 | O'zbekiston poytaxti? | Samarqand | Toshkent | Buxoro | Xiva | 2 | 20`

## Ishtirokchi
- `/lang` — tilni almashtirish
- `/quizzes` — quizlar
- `/play ID` — yakka o'yin
- `/join KOD` — jonli xonaga kirish
- `/leaderboard ID` — reyting

## Muhim
- Bot ishlashi uchun kompyuter/hosting yoqilgan va dastur ishlayotgan bo'lishi kerak.
- Jonli xonalar hozircha bot xotirasida saqlanadi; bot qayta ishga tushsa faol xonalar yopiladi.
- Bu ishlaydigan boshlang'ich MVP. Keyingi versiyada doimiy xona saqlash, to'liq avtomatik taymerni bekor qilish, admin panel, kanal/guruh rejimi va hosting qo'shish mumkin.

import os, asyncio, random, string, time
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from bot import db

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "")
if not TOKEN or TOKEN.startswith("PASTE_"):
    raise RuntimeError("Avval .env fayliga BotFather tokenini kiriting.")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS","").split(",") if x.strip().isdigit()}
bot = Bot(TOKEN)
dp = Dispatcher(storage=MemoryStorage())

T = {
 "uz": {
  "welcome":"🎮 <b>Quiz Arena</b> — Kahoot uslubidagi viktorina!\n\n/quizzes — quizlar\n/play ID — yakka o‘yin\n/create — quiz yaratish (admin)\n/room ID — jonli xona ochish (admin)\n/join KOD — jonli xonaga kirish\n/lang — tilni almashtirish",
  "choose":"Tilni tanlang:", "saved":"Til saqlandi.",
  "noquiz":"Quiz topilmadi yoki e’lon qilinmagan.",
  "empty":"Hozircha e’lon qilingan quiz yo‘q.",
  "joined":"Xonaga qo‘shildingiz! Boshlovchi o‘yinni boshlashini kuting.",
  "started":"O‘yin boshlandi!", "expired":"⏰ Vaqt tugadi!",
  "right":"✅ To‘g‘ri!", "wrong":"❌ Noto‘g‘ri!",
  "done":"🏁 O‘yin tugadi! Natija: <b>{}</b> ball.",
  "roomdone":"🏁 Jonli o‘yin yakunlandi!\n\n{}",
  "notadmin":"Bu buyruq faqat admin uchun.",
  "qtitle":"Quiz nomini yuboring:",
  "created":"Quiz yaratildi. ID: <code>{}</code>\nSavol qo‘shish:\n<code>/add {} | Savol | A | B | C | D | to‘g‘ri javob (1-4) | vaqt</code>\nKeyin /publish {}",
  "added":"Savol qo‘shildi.", "published":"Quiz e’lon qilindi!",
  "badformat":"Format xato. 8 ta maydon bo‘lishi kerak:\n/add ID | Savol | A | B | C | D | javob 1-4 | soniya 5-180",
  "noroom":"Bunday faol xona topilmadi.",
  "room":"Jonli xona kodi: <code>{}</code>\nDo‘stlaringiz /join {} orqali kiradi.\nO‘yin boshlash: /startgame {}",
  "already":"Siz allaqachon javob berdingiz.",
  "wait":"Xona boshlanishini kuting.",
  "leader":"🏆 <b>TOP-10</b>\n{}",
  "noresult":"Hali natijalar yo‘q."
 },
 "ru": {
  "welcome":"🎮 <b>Quiz Arena</b> — викторина в стиле Kahoot!\n\n/quizzes — список викторин\n/play ID — одиночная игра\n/create — создать викторину (админ)\n/room ID — создать комнату (админ)\n/join КОД — войти в комнату\n/lang — сменить язык",
  "choose":"Выберите язык:", "saved":"Язык сохранён.",
  "noquiz":"Викторина не найдена или ещё не опубликована.",
  "empty":"Пока нет опубликованных викторин.",
  "joined":"Вы вошли в комнату! Ждите начала игры.",
  "started":"Игра началась!", "expired":"⏰ Время вышло!",
  "right":"✅ Верно!", "wrong":"❌ Неверно!",
  "done":"🏁 Игра окончена! Ваш результат: <b>{}</b> баллов.",
  "roomdone":"🏁 Игра завершена!\n\n{}",
  "notadmin":"Эта команда доступна только администратору.",
  "qtitle":"Отправьте название викторины:",
  "created":"Викторина создана. ID: <code>{}</code>\nДобавить вопрос:\n<code>/add {} | Вопрос | A | B | C | D | ответ (1-4) | секунды</code>\nЗатем /publish {}",
  "added":"Вопрос добавлен.", "published":"Викторина опубликована!",
  "badformat":"Неверный формат. Нужно 8 полей:\n/add ID | Вопрос | A | B | C | D | ответ 1-4 | секунды 5-180",
  "noroom":"Активная комната не найдена.",
  "room":"Код комнаты: <code>{}</code>\nДрузья входят через /join {}.\nНачать игру: /startgame {}",
  "already":"Вы уже ответили.",
  "wait":"Дождитесь начала игры.",
  "leader":"🏆 <b>ТОП-10</b>\n{}",
  "noresult":"Результатов пока нет."
 }
}
def tr(lang, key): return T.get(lang,T["uz"])[key]

class Create(StatesGroup):
    title = State()

# Active rooms live in memory; restart of bot closes all active rooms.
rooms = {}

def code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

async def send_question(room):
    q = room["questions"][room["index"]]
    room["deadline"] = time.monotonic() + q["seconds"]
    opts = [q["a"],q["b"],q["c"],q["d"]]
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"{i+1}. {v}", callback_data=f"live:{room['code']}:{i+1}")]
        for i,v in enumerate(opts)
    ])
    for uid in list(room["players"]):
        try:
            await bot.send_message(uid, f"❓ <b>{room['index']+1}/{len(room['questions'])}</b>\n{q['body']}\n\n⏱ {q['seconds']}s", reply_markup=markup, parse_mode="HTML")
        except Exception:
            pass
    await asyncio.sleep(q["seconds"])
    if room.get("finished"): return
    await finish_question(room)

async def finish_question(room):
    if room.get("finished"): return
    room["index"] += 1
    if room["index"] >= len(room["questions"]):
        room["finished"] = True
        ranking = sorted(room["players"].items(), key=lambda x:x[1]["points"], reverse=True)
        lines = [f"{i}. {p['name']} — {p['points']} ball" for i,(uid,p) in enumerate(ranking,1)]
        summary = "\n".join(lines) if lines else "Ishtirokchi yo‘q"
        for uid in room["players"]:
            try: await bot.send_message(uid, "🏆 <b>Natijalar</b>\n"+summary, parse_mode="HTML")
            except Exception: pass
        rooms.pop(room["code"], None)
    else:
        await send_question(room)

@dp.message(CommandStart())
async def start(m: Message):
    await db.user(m.from_user.id, m.from_user.full_name)
    lang = await db.lang(m.from_user.id)
    await m.answer(tr(lang,"welcome"), parse_mode="HTML")

@dp.message(Command("lang"))
async def language(m: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🇺🇿 O‘zbekcha", callback_data="lang:uz"),
        InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang:ru")
    ]])
    await m.answer("Til / Язык:", reply_markup=kb)

@dp.callback_query(F.data.startswith("lang:"))
async def set_language(c: CallbackQuery):
    lang = c.data.split(":")[1]
    await db.user(c.from_user.id,c.from_user.full_name)
    await db.set_lang(c.from_user.id,lang)
    await c.answer(tr(lang,"saved"),show_alert=True)
    await c.message.edit_text(tr(lang,"welcome"),parse_mode="HTML")

@dp.message(Command("create"))
async def create(m: Message, state: FSMContext):
    if m.from_user.id not in ADMINS:
        return await m.answer(tr(await db.lang(m.from_user.id),"notadmin"))
    await state.set_state(Create.title)
    await m.answer(tr(await db.lang(m.from_user.id),"qtitle"))

@dp.message(Create.title)
async def create_done(m: Message,state:FSMContext):
    qid=await db.create_quiz(m.text.strip(),m.from_user.id)
    await state.clear()
    await m.answer(tr(await db.lang(m.from_user.id),"created").format(qid,qid,qid),parse_mode="HTML")

@dp.message(Command("add"))
async def add(m:Message):
    lang=await db.lang(m.from_user.id)
    if m.from_user.id not in ADMINS: return await m.answer(tr(lang,"notadmin"))
    p=[x.strip() for x in m.text.partition(" ")[2].split("|")]
    try:
        if len(p)!=8: raise ValueError()
        qid=int(p[0]); correct=int(p[6]); seconds=int(p[7])
        quiz=await db.quiz(qid)
        if not quiz or quiz["owner"]!=m.from_user.id or correct not in (1,2,3,4) or not 5<=seconds<=180: raise ValueError()
        await db.add_question(qid,p[1],p[2:6],correct,seconds)
        await m.answer(tr(lang,"added"))
    except Exception:
        await m.answer(tr(lang,"badformat"))

@dp.message(Command("publish"))
async def publish(m:Message):
    lang=await db.lang(m.from_user.id)
    if m.from_user.id not in ADMINS: return await m.answer(tr(lang,"notadmin"))
    try:
        qid=int(m.text.split()[1]); quiz=await db.quiz(qid); qs=await db.questions(qid)
        if not quiz or quiz["owner"]!=m.from_user.id or not qs: raise ValueError()
        await db.publish(qid,m.from_user.id)
        await m.answer(tr(lang,"published"))
    except Exception: await m.answer("Quiz ID noto‘g‘ri yoki savollar yo‘q.")

@dp.message(Command("quizzes"))
async def quizzes(m:Message):
    items=await db.published_quizzes()
    if not items: return await m.answer(tr(await db.lang(m.from_user.id),"empty"))
    await m.answer("📚 Mavjud quizlar:\n"+"\n".join(f"• {title} — ID: {qid} (/play {qid})" for qid,title in items))

@dp.message(Command("play"))
async def solo(m:Message):
    try: qid=int(m.text.split()[1])
    except: return await m.answer("Foydalanish / Use: /play ID")
    quiz=await db.quiz(qid); qs=await db.questions(qid)
    if not quiz or not quiz["published"] or not qs: return await m.answer(tr(await db.lang(m.from_user.id),"noquiz"))
    room={"code":"SOLO"+str(m.from_user.id),"quiz_id":qid,"questions":qs,"index":0,
          "players":{m.from_user.id:{"name":m.from_user.full_name,"points":0,"answered":False}},
          "finished":False,"solo":True}
    await m.answer(f"🎯 {quiz['title']}")
    await send_solo_question(m,room)

async def send_solo_question(m,room):
    q=room["questions"][room["index"]]
    kb=InlineKeyboardMarkup(inline_keyboard=[
      [InlineKeyboardButton(text=f"{i+1}. {v}",callback_data=f"solo:{room['code']}:{i+1}")]
      for i,v in enumerate([q["a"],q["b"],q["c"],q["d"]])])
    await m.answer(f"❓ {room['index']+1}/{len(room['questions'])}\n{q['body']}\n⏱ {q['seconds']}s",reply_markup=kb)

@dp.callback_query(F.data.startswith("solo:"))
async def solo_answer(c:CallbackQuery):
    _,key,n=c.data.split(":"); uid=c.from_user.id
    # Per-user solo sessions are stored in the room registry.
    room=rooms.get(key)
    if not room: return await c.answer("Bu savol muddati tugagan.",show_alert=True)
    p=room["players"].get(uid)
    if not p or p["answered"]: return await c.answer("Javob qabul qilingan.",show_alert=True)
    q=room["questions"][room["index"]]; p["answered"]=True
    if int(n)==q["correct"]:
        p["points"]+=max(100,1000-int((time.monotonic()-room["started_at"])*20))
        await c.answer(tr(await db.lang(uid),"right"),show_alert=True)
    else: await c.answer(tr(await db.lang(uid),"wrong"),show_alert=True)
    if room["index"]+1<len(room["questions"]):
        room["index"]+=1; p["answered"]=False; room["started_at"]=time.monotonic()
        await send_solo_question(c.message,room)
    else:
        await db.save_result(uid,room["quiz_id"],p["points"])
        await c.message.answer(tr(await db.lang(uid),"done").format(p["points"]),parse_mode="HTML")
        rooms.pop(key,None)

@dp.message(Command("room"))
async def make_room(m:Message):
    lang=await db.lang(m.from_user.id)
    if m.from_user.id not in ADMINS: return await m.answer(tr(lang,"notadmin"))
    try: qid=int(m.text.split()[1])
    except: return await m.answer("Foydalanish /room ID")
    quiz=await db.quiz(qid); qs=await db.questions(qid)
    if not quiz or not quiz["published"] or not qs: return await m.answer(tr(lang,"noquiz"))
    key=code()
    rooms[key]={"code":key,"quiz_id":qid,"questions":qs,"index":0,"players":{},
                "finished":False,"host":m.from_user.id,"solo":False}
    await m.answer(tr(lang,"room").format(key,key,key),parse_mode="HTML")

@dp.message(Command("join"))
async def join(m:Message):
    try: key=m.text.split()[1].upper()
    except: return await m.answer("Foydalanish /join KOD")
    room=rooms.get(key)
    if not room or room.get("finished"): return await m.answer(tr(await db.lang(m.from_user.id),"noroom"))
    room["players"].setdefault(m.from_user.id,{"name":m.from_user.full_name,"points":0,"answered":False})
    await m.answer(tr(await db.lang(m.from_user.id),"joined"))

@dp.message(Command("startgame"))
async def startgame(m:Message):
    try: key=m.text.split()[1].upper()
    except: return await m.answer("Foydalanish /startgame KOD")
    room=rooms.get(key)
    if not room or room.get("host")!=m.from_user.id: return await m.answer("Xona topilmadi yoki siz boshlovchi emassiz.")
    if not room["players"]: return await m.answer("Avval ishtirokchilar kirsin.")
    await m.answer(tr(await db.lang(m.from_user.id),"started"))
    await send_question(room)

@dp.callback_query(F.data.startswith("live:"))
async def live_answer(c:CallbackQuery):
    _,key,n=c.data.split(":"); room=rooms.get(key)
    if not room or room.get("finished"): return await c.answer(tr(await db.lang(c.from_user.id),"noroom"),show_alert=True)
    p=room["players"].get(c.from_user.id)
    if not p: return await c.answer("Avval /join KOD orqali xonaga kiring.",show_alert=True)
    if p["answered"]: return await c.answer(tr(await db.lang(c.from_user.id),"already"),show_alert=True)
    if time.monotonic()>room.get("deadline",0): return await c.answer(tr(await db.lang(c.from_user.id),"expired"),show_alert=True)
    q=room["questions"][room["index"]]; p["answered"]=True
    if int(n)==q["correct"]:
        remaining=max(0,room["deadline"]-time.monotonic())
        p["points"]+=100+int(remaining/q["seconds"]*400)
        await c.answer(tr(await db.lang(c.from_user.id),"right"),show_alert=True)
    else: await c.answer(tr(await db.lang(c.from_user.id),"wrong"),show_alert=True)

@dp.message(Command("leaderboard"))
async def board(m:Message):
    try: qid=int(m.text.split()[1])
    except: return await m.answer("Foydalanish /leaderboard ID")
    rows=await db.leaderboard(qid)
    if not rows: return await m.answer(tr(await db.lang(m.from_user.id),"noresult"))
    lines="\n".join(f"{i}. {name} — {pts}" for i,(name,pts) in enumerate(rows,1))
    await m.answer(tr(await db.lang(m.from_user.id),"leader").format(lines),parse_mode="HTML")

async def main():
    await db.init()
    await dp.start_polling(bot)

if __name__=="__main__":
    asyncio.run(main())

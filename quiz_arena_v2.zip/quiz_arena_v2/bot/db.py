import aiosqlite

DB = "quiz_arena.sqlite3"

async def init():
    async with aiosqlite.connect(DB) as d:
        await d.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(
          user_id INTEGER PRIMARY KEY, name TEXT NOT NULL, lang TEXT NOT NULL DEFAULT 'uz'
        );
        CREATE TABLE IF NOT EXISTS quizzes(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          owner INTEGER NOT NULL, published INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS questions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
          body TEXT NOT NULL, a TEXT NOT NULL, b TEXT NOT NULL, c TEXT NOT NULL, d TEXT NOT NULL,
          correct INTEGER NOT NULL, seconds INTEGER NOT NULL DEFAULT 20
        );
        CREATE TABLE IF NOT EXISTS results(
          user_id INTEGER NOT NULL, quiz_id INTEGER NOT NULL, points INTEGER NOT NULL,
          PRIMARY KEY(user_id, quiz_id)
        );
        """)
        await d.commit()

async def user(user_id, name):
    async with aiosqlite.connect(DB) as d:
        await d.execute("INSERT INTO users(user_id,name) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name", (user_id,name))
        await d.commit()

async def set_lang(user_id, lang):
    async with aiosqlite.connect(DB) as d:
        await d.execute("UPDATE users SET lang=? WHERE user_id=?", (lang,user_id))
        await d.commit()

async def lang(user_id):
    async with aiosqlite.connect(DB) as d:
        cur = await d.execute("SELECT lang FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row[0] if row else "uz"

async def create_quiz(title, owner):
    async with aiosqlite.connect(DB) as d:
        cur = await d.execute("INSERT INTO quizzes(title,owner) VALUES(?,?)", (title,owner))
        await d.commit()
        return cur.lastrowid

async def quiz(qid):
    async with aiosqlite.connect(DB) as d:
        d.row_factory = aiosqlite.Row
        cur = await d.execute("SELECT * FROM quizzes WHERE id=?", (qid,))
        r = await cur.fetchone()
        return dict(r) if r else None

async def add_question(qid, body, opts, correct, seconds):
    async with aiosqlite.connect(DB) as d:
        await d.execute("INSERT INTO questions(quiz_id,body,a,b,c,d,correct,seconds) VALUES(?,?,?,?,?,?,?,?)",
                        (qid,body,*opts,correct,seconds))
        await d.commit()

async def questions(qid):
    async with aiosqlite.connect(DB) as d:
        d.row_factory = aiosqlite.Row
        cur = await d.execute("SELECT * FROM questions WHERE quiz_id=? ORDER BY id", (qid,))
        return [dict(x) for x in await cur.fetchall()]

async def publish(qid, owner):
    async with aiosqlite.connect(DB) as d:
        cur = await d.execute("UPDATE quizzes SET published=1 WHERE id=? AND owner=?", (qid,owner))
        await d.commit()
        return cur.rowcount == 1

async def published_quizzes():
    async with aiosqlite.connect(DB) as d:
        cur = await d.execute("SELECT id,title FROM quizzes WHERE published=1 ORDER BY id DESC")
        return await cur.fetchall()

async def save_result(uid, qid, points):
    async with aiosqlite.connect(DB) as d:
        await d.execute("""INSERT INTO results VALUES(?,?,?)
        ON CONFLICT(user_id,quiz_id) DO UPDATE SET points=MAX(points,excluded.points)""", (uid,qid,points))
        await d.commit()

async def leaderboard(qid):
    async with aiosqlite.connect(DB) as d:
        cur = await d.execute("""SELECT u.name,r.points FROM results r
        JOIN users u ON u.user_id=r.user_id WHERE r.quiz_id=?
        ORDER BY r.points DESC LIMIT 10""", (qid,))
        return await cur.fetchall()
